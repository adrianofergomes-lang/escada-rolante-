# Escada Rolante para iOS

Projeto Xcode com simulador HTML offline e modelos 3D nativos SceneKit.

1. Em um Mac, extraia o ZIP e abra `EscadaRolante.xcodeproj` no Xcode 15 ou posterior.
2. Selecione o target EscadaRolante > Signing & Capabilities > Team (sua conta Apple).
3. Altere o Bundle Identifier para um identificador exclusivo sob seu controle.
4. Escolha um iPhone ou simulador e pressione Run (⌘R).
5. Para distribuir, configure o Apple Developer Program e use Product > Archive.

**Importante:** projeto estruturado, mas ainda não compilado nem testado em Xcode neste ambiente. Não é um arquivo IPA assinado.
